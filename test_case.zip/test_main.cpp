/*------------------------------------------------------------------------------------------*\
This file contains material supporting chapter 8 of the book:
OpenCV3 Computer Vision Application Programming Cookbook
Third Edition
by Robert Laganiere, Packt Publishing, 2016.

This program is free software; permission is hereby granted to use, copy, modify,
and distribute this source code, or portions thereof, for any purpose, without fee,
subject to the restriction that the copyright notice may not be removed
or altered from any source or altered source distribution.
The software is released on an as-is basis and without any warranties of any kind.
In particular, the software is not guaranteed to be fault-tolerant or free from failure.
The author disclaims all warranties with regard to this software, any use,
and any consequent failure, is purely the responsibility of the user.

Copyright (C) 2016 Robert Laganiere, www.laganiere.name
\*------------------------------------------------------------------------------------------*/

#include <iostream>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/xfeatures2d.hpp>




int main()
{
	// SURF:

	// Read input image
	cv::Mat image = cv::imread("../church01.jpg", 0);
	// rotate the image (to produce a horizontal image)
	cv::transpose(image, image);
	cv::flip(image, image, 0);

	std::vector<cv::KeyPoint> keypoints;
	keypoints.clear();
	// Construct the SURF feature detector object
	cv::Ptr<cv::xfeatures2d::SurfFeatureDetector> ptrSURF = cv::xfeatures2d::SurfFeatureDetector::create(2000.0);
	// detect the keypoints
	ptrSURF->detect(image, keypoints);

	// Detect the SURF features
	ptrSURF->detect(image, keypoints);

	cv::Mat featureImage;
	cv::drawKeypoints(image, keypoints, featureImage, cv::Scalar(255, 255, 255), cv::DrawMatchesFlags::DRAW_RICH_KEYPOINTS);

	// Display the keypoints
	cv::namedWindow("SURF");
	cv::imshow("SURF", featureImage);
	//cv::waitKey(0);

	std::cout << "Number of SURF keypoints: " << keypoints.size() << std::endl;

	// Read a second input image
	image = cv::imread("../church03.jpg", cv::IMREAD_GRAYSCALE);
	// rotate the image (to produce a horizontal image)
	cv::transpose(image, image);
	cv::flip(image, image, 0);

	// Detect the SURF features
	ptrSURF->detect(image, keypoints);

	cv::drawKeypoints(image, keypoints, featureImage, cv::Scalar(255, 255, 255), cv::DrawMatchesFlags::DRAW_RICH_KEYPOINTS);

	// Display the keypoints
	cv::namedWindow("SURF (2)");
	cv::imshow("SURF (2)", featureImage);

	

	cv::waitKey(0);
	return 0;
}